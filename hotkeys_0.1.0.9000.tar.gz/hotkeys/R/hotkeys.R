#' RStudio shortcuts
#' @name
#' @docType package
#' @import rstudioapi
NULL
